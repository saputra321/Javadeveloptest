package com.dansmultipro.recruitment.controller;

import com.dansmultipro.recruitment.dto.PositionDto;
import com.dansmultipro.recruitment.service.RecruitmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/v1/recruitments")
public class RecruitmentController {

    @Autowired
    private RecruitmentService recruitmentService;

    @GetMapping("jobs")
    public ResponseEntity<List<PositionDto>> retrieveJobs() {
        return ResponseEntity.ok(recruitmentService.retrievePositions());
    }

    @GetMapping("jobs/{id}")
    public ResponseEntity<PositionDto> retrieveJobById(
            @PathVariable(value = "id") String id) {
        return ResponseEntity.ok(recruitmentService.retrievePositionById(id));
    }
}
