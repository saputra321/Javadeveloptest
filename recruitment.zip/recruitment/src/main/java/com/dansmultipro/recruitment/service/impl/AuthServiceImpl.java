package com.dansmultipro.recruitment.service.impl;

import com.dansmultipro.recruitment.dto.LoginDto;
import com.dansmultipro.recruitment.dto.RegisterDto;
import com.dansmultipro.recruitment.exception.RecruitmentException;
import com.dansmultipro.recruitment.model.Users;
import com.dansmultipro.recruitment.repository.UsersRepository;
import com.dansmultipro.recruitment.security.JwtTokenProvider;
import com.dansmultipro.recruitment.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthServiceImpl implements AuthService {

    @Autowired
    private AuthenticationManager authenticationManager;
    @Autowired
    private UsersRepository userRepository;
    @Autowired
    private PasswordEncoder passwordEncoder;
    @Autowired
    private JwtTokenProvider jwtTokenProvider;

    @Override
    public String login(LoginDto loginDto) {
        try {
            Authentication authentication = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(
                    loginDto.getUsername(), loginDto.getPassword()));
            SecurityContextHolder.getContext().setAuthentication(authentication);
            String token = jwtTokenProvider.generateToken(authentication);
            return token;
        } catch (Exception e) {
            throw new RecruitmentException(HttpStatus.UNAUTHORIZED, e.getMessage());
        }
    }

    @Override
    public String register(RegisterDto registerDto) {
        // add check for username exists in database
        var usersOptional = userRepository.findByUsername(registerDto.getUsername());
        if (usersOptional.isPresent()) {
            throw new RecruitmentException(HttpStatus.BAD_REQUEST, "Username is already exists!.");
        }

        Users user = new Users();
        user.setUsername(registerDto.getUsername());
        user.setPassword(passwordEncoder.encode(registerDto.getPassword()));
        userRepository.save(user);

        return "User registered successfully!.";
    }
}
