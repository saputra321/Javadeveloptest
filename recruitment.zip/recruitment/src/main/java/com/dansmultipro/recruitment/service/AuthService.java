package com.dansmultipro.recruitment.service;

import com.dansmultipro.recruitment.dto.LoginDto;
import com.dansmultipro.recruitment.dto.RegisterDto;

public interface  AuthService {

    String login(LoginDto loginDto);

    String register(RegisterDto registerDto);
}
