package com.dansmultipro.recruitment.service;

import com.dansmultipro.recruitment.dto.PositionDto;

import java.util.List;

public interface RecruitmentService {

    List<PositionDto> retrievePositions();
    PositionDto retrievePositionById(String id);
}
