package com.dansmultipro.recruitment.controller;

import com.dansmultipro.recruitment.dto.JWTAuthResponse;
import com.dansmultipro.recruitment.dto.LoginDto;
import com.dansmultipro.recruitment.dto.RegisterDto;
import com.dansmultipro.recruitment.exception.RecruitmentException;
import com.dansmultipro.recruitment.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("api/v1/auth")
public class AuthController {

    @Autowired
    private AuthService authService;

    // Build Login REST API
    @PostMapping("login")
    public ResponseEntity<Object> login(@RequestBody LoginDto loginDto) {
        try {
            String token = authService.login(loginDto);

            JWTAuthResponse jwtAuthResponse = new JWTAuthResponse();
            jwtAuthResponse.setAccessToken(token);

            return ResponseEntity.ok(jwtAuthResponse);
        } catch (RecruitmentException e) {
            return new ResponseEntity<>(e.getMessage(), e.getStatus());
        }
    }

    // Build Register REST API
    @PostMapping("register")
    public ResponseEntity<String> register(@RequestBody RegisterDto registerDto) {
        try {
            String response = authService.register(registerDto);
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (RecruitmentException e) {
            return new ResponseEntity<>(e.getMessage(), e.getStatus());
        }
    }
}
