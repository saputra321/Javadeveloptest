package com.dansmultipro.recruitment.service.impl;

import com.dansmultipro.recruitment.dto.PositionDto;
import com.dansmultipro.recruitment.service.RecruitmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Service
public class RecruitmentServiceImpl implements RecruitmentService {

    @Autowired
    private RestTemplate restTemplate;

    @Override
    public List<PositionDto> retrievePositions() {
        String url = "http://dev3.dansmultipro.co.id/api/recruitment/positions.json";
        var response = restTemplate.getForEntity(url, PositionDto[].class);
        return List.of(response.getBody());
    }

    @Override
    public PositionDto retrievePositionById(String id) {
        String url = "http://dev3.dansmultipro.co.id/api/recruitment/positions/{id}";
        var response = restTemplate.getForEntity(url, PositionDto.class, id);
        return response.getBody();
    }
}
